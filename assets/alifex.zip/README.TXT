
Life Explosion is Win9x/NT Screen Saver.It is FREEWARE and freely
distributabl.
Run setup to install.
Author Igor Samtsevich igors@cz.itmo.by
Homepage http://cz.itmo.by/javas/lifex/index.htm
